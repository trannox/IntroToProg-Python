# Title: Demonstration of Exception Handling
# These script snippets anticipates where user input could crash Python and mitigates that.
# Dev: ttruong
# Date: 8.25.19
# Changelog: 8.25.19 - Codes are beginners' level. Future me will come back and optimize codes for fun and profit!)

"""

# Snippet 1 - try/except

intAge0 = ""
while intAge0 is not int:
    try:    # user input is always a string, converting string to integer is common
        intAge0 = int(input("Student 1 - Enter age: \n"))
        break
    except ValueError:  # catching instances where users enter a non-number value and prevents program crashing
        print("Please only enter a number")

intAge1 = ""    # Python crashes when it tries to convert letters to integers
while intAge1 is not int:
    intAge11 = int(input("Student 2 - Enter age: \n"))



# Snippet 2 - Getting the exception's argument.


while True:
    intAge0 = ""
    while intAge0 is not int:
        try:
            intAge0 = int(input("Student 1 - Enter age: \n"))
            break
        except ValueError as e: # Getting Python's argument for the exception
            print("Not a number. Python's message is: ")
            print(e)



"""

# Snippet 3 - try/except and else


while True:
    intAge0 = ""
    while intAge0 is not int:
        try:
            intAge0 = int(input("Student 1 - Enter age: \n"))
        except ValueError as e:
            print("Not a number. Python's message is: ")
            print(e)
        else:
            print("That's a number!", intAge0)

