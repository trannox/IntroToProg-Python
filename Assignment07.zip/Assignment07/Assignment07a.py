import pickle
dataFields = int(input('Enter the number of data fields: '))        # take count of data fields
lstData = []

for i in range(dataFields):            # take input of the data
    entry = input('Enter data '+str(i)+' : ')
    lstData.append(entry)

objFile = open("/Users/tran/Documents/PythonClass/Assignment07/Customer.dat", 'wb')
pickle.dump(lstData, objFile)       # dump information to that file
objFile.close()     # close the file

# open file to load pickled data
objFile = open("/Users/tran/Documents/PythonClass/Assignment07/Customer.dat", 'rb')

lstData = pickle.load(objFile)  # load information to that file
objFile.close()

print('\nShowing the pickled data: \n')

cnt = 0
for item in lstData:
    print('The data ', cnt, ' is : ', item)
    cnt += 1

